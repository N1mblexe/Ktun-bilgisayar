def ifadeyi_hesapla(expression):
    # Boş bir yığıt (stack) oluşturuyoruz.
    stack = []

    # İşlem operatörlerini içeren bir küme oluşturuyoruz.
    operators = set(['+', '-', '*', '/'])

    # İfadeyi kullanıcının girdiği metinden boşluklara göre ayırarak tokenlara bölüyoruz.
    tokens = expression.split()

    # Tokenları tersten ele alarak işlemleri gerçekleştiriyoruz.
    for token in reversed(tokens):
        # Eğer token bir sayı ise, onu integer'a çevirip yığıta ekliyoruz.
        if token.isdigit():
            stack.append(int(token))
        # Eğer token bir işlem operatörü ise, yığıttan iki operand çekip işlemi gerçekleştirip sonucu yığıta ekliyoruz.
        elif token in operators:
            operand1 = stack.pop()
            operand2 = stack.pop()
            if token == '+':
                stack.append(operand1 + operand2)
            elif token == '-':
                stack.append(operand1 - operand2)
            elif token == '*':
                stack.append(operand1 * operand2)
            elif token == '/':
                stack.append(operand1 / operand2)
        # Eğer token hem sayı değil hem de işlem operatörü değilse, geçersiz bir ifade olduğunu belirtiyoruz.
        else:
            print("Geçersiz simge:", token)
            return None

    # Yığıtta sadece bir eleman kaldıysa, bu sonuçtur.
    if len(stack) == 1:
        return stack.pop()
    # Yığıtta birden fazla eleman varsa, geçersiz bir ifade olduğunu belirtiyoruz.
    else:
        print("Geçersiz ifade")
        return None

# Kullanıcıdan giriş alınması
input_expression = input("Polish notasyonundaki aritmetik ifadeyi girin (örn. '* + * + 1 2 + 3 4 5 6'): ")

# İfadenin sonucunu hesaplayıp ekrana yazdırma
result = ifadeyi_hesapla(input_expression)
if result is not None:
    print("Sonuç:", result)