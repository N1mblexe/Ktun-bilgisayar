class CFGIslemleri:
    def __init__(self):
        self.words = []
        self.repeated_words = []

    def string_islemleri(self):
        alphabet = input("Alfabeyi giriniz. Örn: Σ={a,b,X}\n")
        if alphabet.lower() == 'q':
            exit()

        CFG = input("CFG yi giriniz. Örn: S-->aX|bb|aXb,X-->a|b|aba\n")
        if CFG.lower() == 'q':
            exit()

        cfg_parts = CFG.split(',')
        self.cfg0 = cfg_parts[0][cfg_parts[0].index('>') + 1:].split('|')
        self.cfg1 = cfg_parts[1][cfg_parts[1].index('>') + 1:].split('|')

        for i in self.cfg0:
            if 'X' in i:
                self.deger_ekle(i)
            else:
                self.listele(i)

    def deger_ekle(self, word):
        for i in self.cfg1:
            toplam = ""
            ilk_x = True
            for a in word:
                if a == 'X' and ilk_x:
                    toplam += i
                    ilk_x = False
                else:
                    toplam += a

            if 'X' in toplam:
                self.deger_ekle(toplam)
            else:
                self.listele(toplam)

    def listele(self, word):
        if word not in self.words:
            self.words.append(word)
        else:
            self.repeated_words.append(word)

    def yazdir(self):
        print("Üretilen kelimeler:")
        print(', '.join(self.words))
        print("\nTekrarlanan kelimeler:")
        print(', '.join(self.repeated_words))


def main():
    while True:
        cfg = CFGIslemleri()
        cfg.string_islemleri()
        cfg.yazdir()
        if input("Devam etmek için ENTER'a basın, çıkış yapmak için Q'ya basın: ").lower() == 'q':
            break

if __name__ == "__main__":
    main()
